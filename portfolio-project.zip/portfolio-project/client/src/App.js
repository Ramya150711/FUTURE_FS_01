import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Navbar from "./components/Navbar";
import Hero from "./components/Hero";
import Projects from "./components/Projects";
import Contact from "./components/Contact";

import PortfolioWebsite from "./components/ProjectDetails/PortfolioWebsite";
import LoginSignupSystem from "./components/ProjectDetails/LoginSignupSystem";
import PanCardModel from "./components/ProjectDetails/PanCardModel";

function App() {
  return (
    <Router>
      <Navbar />
      <Routes>
        <Route path="/" element={
          <>
            <Hero />
            <Projects />
            <Contact />
          </>
        } />
        <Route path="/projects/portfolio-website" element={<PortfolioWebsite />} />
        <Route path="/projects/login-signup-system" element={<LoginSignupSystem />} />
        <Route path="/projects/pan-card-model" element={<PanCardModel />} />
      </Routes>
    </Router>
  );
}

export default App;
