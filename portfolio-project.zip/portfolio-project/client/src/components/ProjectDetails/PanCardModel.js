import React from 'react';
const PanCardModel = () => {
  return (
    <div style={{ padding: "2rem" }}>
      <h2>OCR PAN Card Model</h2>
      <p>This project extracts information from Indian PAN cards using Optical Character Recognition (OCR) powered by Tesseract.js or Google Vision API. It helps verify identity in real-time systems.</p>
    </div>
  );
};

export default PanCardModel;
