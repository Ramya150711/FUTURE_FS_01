import React from 'react';
const PortfolioWebsite = () => {
  return (
    <div style={{ padding: "2rem" }}>
      <h2>Portfolio Website</h2>
      <p>This project showcases my personal portfolio made with React and Node.js backend (optional) and MongoDB/MySQL for contact forms. It includes responsive design, SEO optimization, and project showcase functionality.</p>
    </div>
  );
};

export default PortfolioWebsite;
