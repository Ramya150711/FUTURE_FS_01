import React from 'react';
const LoginSignupSystem = () => {
  return (
    <div style={{ padding: "2rem" }}>
      <h2>Login/Signup System</h2>
      <p>This project implements user authentication using Node.js, bcrypt for password hashing, MongoDB for storage, and a React frontend with toast notifications.</p>
    </div>
  );
};

export default LoginSignupSystem;
