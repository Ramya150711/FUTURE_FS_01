import React from 'react';
import './styles/Hero.css';

const Hero = () => {
  return (
    <section id="hero" className="hero-section">
      <h1>Hello, I'm Ramya 👋</h1>
      <p>Frontend Developer | React Enthusiast</p>
    </section>
  );
};

export default Hero;
