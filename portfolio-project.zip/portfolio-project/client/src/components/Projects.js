import React from 'react';
import { Link } from 'react-router-dom';
import './styles/Projects.css';

const Projects = () => {
  return (
    <section id="projects" className="projects-section">
      <h2>Projects</h2>
      <ul>
        <li><Link to="/projects/portfolio-website">✅ Portfolio Website</Link></li>
        <li><Link to="/projects/login-signup-system">✅ Login/Signup System</Link></li>
        <li><Link to="/projects/pan-card-model">✅ OCR PAN Card Model</Link></li>
      </ul>
    </section>
  );
};

export default Projects;
